            function toggleMenu() {
    let toggle = document.querySelector('.toggle');
    let sidebar = document.querySelector('.sidebar');

    toggle.classList.toggle('active');
    sidebar.classList.toggle('active');
}

var hidden = false;
    function action() {
        hidden = !hidden;
        if(hidden) {
            document.getElementById('togglee').style.visibility = 'hidden';
        } else {
            document.getElementById('togglee').style.visibility = 'visible';
        }
    }

