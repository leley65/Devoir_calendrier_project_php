<?php

class score {
    private $team1;
    private $team2;
    
    public function __construct ($t1,$t2){
        $this->team1 = $t1;
        $this->team2 = $t2;
    }
    
    public function setTeam1($t1){
        $this->team1 = $t1;
    }
    
    public function setTeam2($t2){
        $this->team2 = $t2;
    }
    
    public function getTeam1(){
        return $this->team1;
    }
    
    public function getTeam2(){
        return $this->team2;
    }
}

?>
