<?php

class team {
    private $nom;
    private $lot;
    private $mj = 0;
    private  $mg = 0;
    private $mn = 0;
    private $mp = 0;
    private $bp = 0;
    private $bc = 0;
    private $point = 0;


    public function __construct ($n,$l){
        $this->nom = $n;
        $this->lot = $l;
    }
    
    public function setNom($n){
        $this->nom = $n;
    }
    
    public function setLot($l){
        $this->lot = $l;
    }
    
    public function getNom(){
        return $this->nom;
    }
    
    public function getLot(){
        return $this->lot;
    }
    
    function getMj() {
        return $this->mj;
    }

    function getMg() {
        return $this->mg;
    }

    function getMn() {
        return $this->mn;
    }

    function getMp() {
        return $this->mp;
    }

    function getBp() {
        return $this->bp;
    }

    function getBc() {
        return $this->bc;
    }

    function getPoint() {
        return $this->point;
    }

    function setMj($mj) {
        $this->mj = $mj;
    }

    function setMg($mg) {
        $this->mg = $mg;
    }

    function setMn($mn) {
        $this->mn = $mn;
    }

    function setMp($mp) {
        $this->mp = $mp;
    }

    function setBp($bp) {
        $this->bp = $bp;
    }

    function setBc($bc) {
        $this->bc = $bc;
    }

    function setPoint($point) {
        $this->point = $point;
    }
    
    function resetTeamParameters(){
        $this->mj = 0;
        $this->mg = 0;
        $this->mn = 0;
        $this->mp = 0;
        $this->bp = 0;
        $this->bc = 0;
        $this->point = 0;
    }

    public static function setTeamParameters($team, $scoretab, $a, $b, $sc){
    
        $team[$a]->setMj($team[$a]->getMj()+1);
        $team[$b]->setMj($team[$b]->getMj()+1);

        $team[$a]->setBp($team[$a]->getBp()+$scoretab[$sc]->getTeam1());
        $team[$b]->setBp($team[$b]->getBp()+$scoretab[$sc]->getTeam2());
        
        $team[$a]->setBc($team[$a]->getBc()+$scoretab[$sc]->getTeam2());
        $team[$b]->setBc($team[$b]->getBc()+$scoretab[$sc]->getTeam1());

        if($scoretab[$sc]->getTeam1()>$scoretab[$sc]->getTeam2()){
            $team[$a]->setPoint($team[$a]->getPoint()+3);
            $team[$a]->setMg($team[$a]->getMg()+1);
            $team[$b]->setMp($team[$b]->getMp()+1);
        }else if($scoretab[$sc]->getTeam1()<$scoretab[$sc]->getTeam2()){
            $team[$b]->setPoint($team[$b]->getPoint()+3);
            $team[$b]->setMg($team[$b]->getMg()+1);
            $team[$a]->setMp($team[$a]->getMp()+1);
        }else{
            $team[$a]->setPoint($team[$a]->getPoint()+1);
            $team[$a]->setMn($team[$a]->getMn()+1);

            $team[$b]->setPoint($team[$b]->getPoint()+1);
            $team[$b]->setMn($team[$b]->getMn()+1);
        }         
    }


    public static function orderClassement($table){        
        for($i = 1; $i <= count($table); $i++){
            for($j = 1; $j <= count($table); $j++){
                if($table[$i]->getPoint() > $table[$j]->getPoint()){
                    $temp = $table[$i];
                    $table[$i]= $table[$j];
                    $table[$j] = $temp;
                }else if($table[$i]->getPoint() == $table[$j]->getPoint()){
                    if($table[$i]->getBp() > $table[$j]->getBp()){
                        $temp = $table[$i];
                        $table[$i]= $table[$j];
                        $table[$j] = $temp;
                    }else if($table[$i]->getBp() == $table[$j]->getBp()){                        
                        if($table[$i]->getBc() > $table[$j]->getBc()){
                            $temp = $table[$i];
                            $table[$i]= $table[$j];
                            $table[$j] = $temp;
                        }
                    }
                }
            }
        }

        return $table;
    }
    
    public static function demiFinal($team ,$scoretab, $a, $b, $sc){
        $winner=null;
        while ($scoretab[$sc]->getTeam1()==$scoretab[$sc]->getTeam2()){
            $scoretab[$sc]=new score(rand(0, 5), rand(0, 5));
            echo '<br>penalties '.$team[$a]->getNom().' : '.$scoretab[$sc]->getTeam1().' - '.$team[$b]->getNom().' : '.$scoretab[$sc]->getTeam2().'<br>';          
        }
        
        if($scoretab[$sc]->getTeam1()<$scoretab[$sc]->getTeam2()){
            $winner = $team[$b];
        }else{
            $winner = $team[$a];
        }
        
        return $winner;
    }
}
?>
