<?php
include 'team.class.php';
include 'score.class.php';
session_start();

$first = $_SESSION['first'] ?? null;
$second = $_SESSION['second'] ?? null;

$scoretab = $_SESSION['scoretab'] ?? null;
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="custom\css\index.css">
         <link rel="stylesheet" type="text/css" href="custom\package\dist\sweetalert2.min.js">
         <link rel="stylesheet" type="text/css" href="custom\flag-icon-css-master\css\flag-icon.min.css">

        <script type="text/javascript" src="custom\all.js"></script>
        <script type="text/javascript" src="custom\js\index.js"></script>
        <script type="text/javascript" src="custom\package\dist\sweetalert2.all.js"></script>


        <title>Calendrier | index</title>
    </head>
    <body>        
        
        <form class="container" method="post" action="action.php">
             <div class="sidebar">
            <div class="logo_content">
                <div class="logo">
                    <span class="icon"><i class="fas fa-futbol"></i></span>
                    <div class="logo_name">Calendrier football</div>
                </div>
                <div class="toggle" onclick="toggleMenu();">
                <span class="icon"><i class="fas fa-bars" id="btn"></i></span>
                </div>
            </div>
            <ul class="nav_list">
                <li>
              
                        <span class="icon"><i class="fas fa-tachometer-alt"></i></span>
                        <span class="links_name">
                        <input class="btn btn-info" type='submit' value="Tirage" name="submit" id="toggler" onClick="action();" />
                    </span>
                    
                     <span class="tooltip">Tirage</span> 
                </li>
                <li>
                    
                        <span class="icon"><i class="fas fa-check-circle"></i></span>
                        <span class="links_name">
                         <input class="nav-item btn btn-info" type="submit" value="Simulation" name="submit" id="togglee"/>
                     </span>
                   
                     <span class="tooltip">Simulation</span>
                </li>
                <li>
                    
                        <span class="icon"><i class="fas fa-save"></i></span>
                        <span class="links_name"><input class="nav-item btn btn-info" type="submit" value="Resultats" name="submit"></span>
                   
                    <span class="tooltip">Resultats</span> 
                </li>
                <li>
                    
                        <span class="icon"><i class="fas fa-sync-alt"></i></span>
                        <span class="links_name">
                            <input class="nav-item btn btn-info" type="submit" value="Reinitialiser" name="submit">
                        </span>
                   
                     <span class="tooltip">Reintialiser</span> 
                </li>
            </ul>
        </div>

        <div class="home_content">

              <div class="container p-30">
                                <div class="row">
                                    <div class="col-md-12 main-datatable">
                                        <div class="card_body">
                                
                                            <div class="overflow-x">




                    <h3>Equipes</h3>
                <table>
                    <thead>
                        <tr>
                            <th> Lot #1<br> (1e tete de serie)</th>
                            <th> Lot #2<br> (2e tete de serie)</th>
                            <th> Lot #3<br> (3e tete de serie)</th>
                            <th> Lot #4<br> (4e tete de serie)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><span class="flag-icon flag-icon-br"></span> Bresil</td>
                            <td><span class="flag-icon flag-icon-fr"></span> France</td>
                            <td><span class="flag-icon flag-icon-es"></span> Espagne</td>
                            <td><span class="flag-icon flag-icon-pt"></span> Portugal</td>
                        </tr>
                        <tr>
                            <td><span class="flag-icon flag-icon-ar"></span> Argentine</td>
                            <td><span class="flag-icon flag-icon-it"></span> Italie</td>
                            <td><span class="flag-icon flag-icon-be"></span> Allemagne</td>
                            <td><span class="flag-icon flag-icon-ht"></span> Haiti</td>
                        </tr>
                    </tbody>
                </table>
                <br>

            <?php
            if (!empty($first) || !empty($second)) {
                ?>
            <div>
                    <h3>Resutats Tirage</h3>
                    <table>
                        <thead>
                            <tr>
                                <th></th>
                                <th>Groupe A</th>
                                <th>Groupe B</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            for ($i = 1; $i <= 4; $i++) {
                                ?>
                                <tr>
                                    <td><?= $i . 'e Tete de Serie (TDS)'; ?></td>
                                    <td><?= $first[$i]-> getNom() ?></td>
                                    <td><?= $second[$i]->getNom() ?></td>
                                </tr>
                            <?php }
                            ?>
                        </tbody>
                    </table>
                    <br>
                    </div>


                    <?php
                    foreach ($first as $value) {
                        $value->resetTeamParameters();
                    }
                    foreach ($second as $value) {
                        $value->resetTeamParameters();
                    }
                    ?>

                    <h3>Match Groupe A</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Groupe A</th>
                                <th>Affiche</th>
                                <th>Score</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>                
                                <td>1er Match</td>
                                <td><?= $first[1]->getNom() ?> VS <?= $first[2]->getNom() ?></td>
                                <td><input type="number" disabled="" value="<?= empty($scoretab[1]) ? null : $scoretab[1]->getTeam1() ?>" name="match1"> - 
                                    <input type="number" disabled="" value="<?= empty($scoretab[1]) ? null : $scoretab[1]->getTeam2() ?>" name="match1-1"></td>
                                <?php
                                if (!empty($scoretab[1])) {
                                    team::setTeamParameters($first, $scoretab, 1, 2, 1);
                                }
                                ?>
                            </tr>
                            <tr>
                                <td>2eme Match</td>
                                <td><?= $first[3]->getNom() ?> VS <?= $first[4]->getNom() ?></td>
                                <td><input type="number" disabled="" value="<?= empty($scoretab[2]) ? null : $scoretab[2]->getTeam1() ?>" name="match2"> - 
                                    <input type="number" disabled="" value="<?= empty($scoretab[2]) ? null : $scoretab[2]->getTeam2() ?>" name="match2-2"></td>
                                <?php
                                if (!empty($scoretab[2])) {
                                    team::setTeamParameters($first, $scoretab, 3, 4, 2);
                                }
                                ?>
                            </tr>
                            <tr>
                                <td>3eme Match</td>
                                <td><?= $first[1]->getNom() ?> VS <?= $first[3]->getNom() ?></td>
                                <td><input type="number" disabled="" value="<?= empty($scoretab[3]) ? null : $scoretab[3]->getTeam1() ?>" name="match3"> - 
                                    <input type="number" disabled="" value="<?= empty($scoretab[3]) ? null : $scoretab[3]->getTeam2() ?>" name="match3-3"></td>
                                <?php
                                if (!empty($scoretab[3])) {
                                    team::setTeamParameters($first, $scoretab, 1, 3, 3);
                                }
                                ?>
                            </tr>
                            <tr>
                                <td>4eme Match</td>
                                <td><?= $first[2]->getNom() ?> VS <?= $first[4]->getNom() ?></td>
                                <td><input type="number" disabled="" value="<?= empty($scoretab[4]) ? null : $scoretab[4]->getTeam1() ?>" name="match4"> -
                                 <input type="number" disabled="" value="<?= empty($scoretab[4]) ? null : $scoretab[4]->getTeam2() ?>" name="match4-4"></td>
                                <?php
                                if (!empty($scoretab[4])) {
                                    team::setTeamParameters($first, $scoretab, 2, 4, 4);
                                }
                                ?>
                            </tr>

                            <tr>
                                <td>5eme Match</td>
                                <td><?= $first[1]->getNom() ?> VS <?= $first[4]->getNom() ?></td>
                                <td><input type="number" disabled="" value="<?= empty($scoretab[5]) ? null : $scoretab[5]->getTeam1() ?>" name="match5"> - 
                                    <input type="number" disabled="" value="<?= empty($scoretab[5]) ? null : $scoretab[5]->getTeam2() ?>" name="match5-5"></td>
                                <?php
                                if (!empty($scoretab[5])) {
                                    team::setTeamParameters($first, $scoretab, 1, 4, 5);
                                }
                                ?>
                            </tr>
                            <tr>
                                <td>6eme Match</td>
                                <td><?= $first[2]->getNom() ?> VS <?= $first[3]->getNom() ?></td>
                                <td><input type="number" disabled="" value="<?= empty($scoretab[6]) ? null : $scoretab[6]->getTeam1() ?>" name="match6"> - 
                                    <input type="number" disabled="" value="<?= empty($scoretab[6]) ? null : $scoretab[6]->getTeam2() ?>" name="match6-6"></td>
                                <?php
                                if (!empty($scoretab[6])) {
                                    team::setTeamParameters($first, $scoretab, 2, 3, 6);
                                }
                                ?>
                            </tr>
                        </tbody>            
                    </table>

  
                    <h3>Match Groupe B</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Groupe B</th>
                                <th>Affiche</th>
                                <th>Score</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>                
                                <td>7eme Match</td>
                                <td><?= $second[1]->getNom() ?> VS <?= $second[2]->getNom() ?></td>
                                <td><input type="number" disabled="" value="<?= empty($scoretab[7]) ? null : $scoretab[7]->getTeam1() ?>" name="match7"> - 
                                    <input type="number" disabled="" value="<?= empty($scoretab[7]) ? null : $scoretab[7]->getTeam2() ?>" name="match7-7" ></td>
                                <?php
                                if (!empty($scoretab[7])) {
                                    team::setTeamParameters($second, $scoretab, 1, 2, 7);
                                }
                                ?>
                            </tr>
                            <tr>
                                <td>8eme Match</td>
                                <td><?= $second[3]->getNom() ?> VS <?= $second[4]->getNom() ?></td>
                                <td><input type="number" disabled="" value="<?= empty($scoretab[8]) ? null : $scoretab[8]->getTeam1() ?>" name="match8"> - 
                                    <input type="number" disabled="" value="<?= empty($scoretab[8]) ? null : $scoretab[8]->getTeam2() ?>" name="match8-8"></td>
                                <?php
                                if (!empty($scoretab[8])) {
                                    team::setTeamParameters($second, $scoretab, 3, 4, 8);
                                }
                                ?>
                            </tr>
                            <tr>
                                <td>9eme Match</td>
                                <td><?= $second[1]->getNom() ?> VS <?= $second[3]->getNom() ?></td>
                                <td><input type="number" disabled="" value="<?= empty($scoretab[9]) ? null : $scoretab[9]->getTeam1() ?>" name="match9"> - 
                                    <input type="number" disabled="" value="<?= empty($scoretab[9]) ? null : $scoretab[9]->getTeam2() ?>" name="match9-9"></td>
                                <?php
                                if (!empty($scoretab[9])) {
                                    team::setTeamParameters($second, $scoretab, 1, 3, 9);
                                }
                                ?>
                            </tr>
                            <tr>
                                <td>10eme Match</td>
                                <td><?= $second[2]->getNom() ?> VS <?= $second[4]->getNom() ?></td>
                                <td><input type="number" disabled="" value="<?= empty($scoretab[10]) ? null : $scoretab[10]->getTeam1() ?>" name="match10"> - 
                                    <input type="number" disabled="" value="<?= empty($scoretab[10]) ? null : $scoretab[10]->getTeam2() ?>" name="match10-10"></td>
                                <?php
                                if (!empty($scoretab[10])) {
                                    team::setTeamParameters($second, $scoretab, 2, 4, 10);
                                }
                                ?>
                            </tr>

                            <tr>
                                <td>11eme Match</td>
                                <td><?= $second[1]->getNom() ?> VS <?= $second[4]->getNom() ?></td>
                                <td><input type="number" disabled="" value="<?= empty($scoretab[11]) ? null : $scoretab[11]->getTeam1() ?>" name="match11"> - 
                                    <input type="number" disabled="" value="<?= empty($scoretab[11]) ? null : $scoretab[11]->getTeam2() ?>" name="match11-11"></td>
                                <?php
                                if (!empty($scoretab[11])) {
                                    team::setTeamParameters($second, $scoretab, 1, 4, 11);
                                }
                                ?>
                            </tr>
                            <tr>
                                <td>12eme Match</td>
                                <td><?= $second[2]->getNom() ?> VS <?= $second[3]->getNom() ?></td>
                                <td><input type="number" disabled="" value="<?= empty($scoretab[12]) ? null : $scoretab[12]->getTeam1() ?>" name="match12"> - 
                                    <input type="number" disabled="" value="<?= empty($scoretab[12]) ? null : $scoretab[12]->getTeam2() ?>" name="match12-12"></td>
                                <?php
                                if (!empty($scoretab[12])) {
                                    team::setTeamParameters($second, $scoretab, 2, 3, 12);
                                }
                                ?>
                            </tr>
                        </tbody>
                    </table>

                    <br>
   
                <br>
                <?php
                $first = team::orderClassement($first);
                $second = team::orderClassement($second);
            }
            if (!empty($scoretab)) {
                ?>

                    <table>
                        <h3>Classements</h3>
                        <thead>
                            <tr>
                                <th colspan="9">Groupe A</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th></th>
                                <th>MJ</th>
                                <th>MG</th>
                                <th>MN</th>
                                <th>MP</th>
                                <th>BP</th>
                                <th>BC</th>
                                <th>Diff</th>
                                <th>Point</th>
                            </tr>
                            <?php
                            for ($i = 1; $i <= 4; $i++) {

                                switch ($i) {
                                    case 1:
                                        $teamC[$i] = $first[$i];
                                        break;

                                    case 2:
                                        $teamC[$i] = $first[$i];
                                        break;
                                }
                                ?>
                                <tr>
                                    <td><?= $first[$i]->getNom(); ?></td>
                                    <td><?= $first[$i]->getMj() ?></td>
                                    <td><?= $first[$i]->getMg() ?></td>
                                    <td><?= $first[$i]->getMn() ?></td>
                                    <td><?= $first[$i]->getMp() ?></td>
                                    <td><?= $first[$i]->getBp() ?></td>
                                    <td><?= $first[$i]->getBc() ?></td>
                                    <td><?= $first[$i]->getBp() - $first[$i]->getBc() ?></td>
                                    <td><?= $first[$i]->getPoint() ?></td>
                                </tr>
        <?php
    }
    ?>
                        </tbody>
                    </table>
  
                <br>

                    <table>
                        <thead>
                            <tr>
                                <th colspan="9">Groupe B</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th></th>
                                <th>MJ</th>
                                <th>MG</th>
                                <th>MN</th>
                                <th>MP</th>
                                <th>BP</th>
                                <th>BC</th>
                                <th>Diff</th>
                                <th>Point</th>
                            </tr>
    <?php
    for ($i = 1; $i <= 4; $i++) {
        switch ($i) {
            case 1:
                $teamC[$i + 2] = $second[$i];
                break;

            case 2:
                $teamC[$i + 2] = $second[$i];
                break;
        }
        ?>
                                <tr>
                                    <td><?= $second[$i]->getNom(); ?></td>
                                    <td><?= $second[$i]->getMj() ?></td>
                                    <td><?= $second[$i]->getMg() ?></td>
                                    <td><?= $second[$i]->getMn() ?></td>
                                    <td><?= $second[$i]->getMp() ?></td>
                                    <td><?= $second[$i]->getBp() ?></td>
                                    <td><?= $second[$i]->getBc() ?></td>
                                    <td><?= $second[$i]->getBp() - $second[$i]->getBc() ?></td>
                                    <td><?= $second[$i]->getPoint() ?></td>
                                </tr>
        <?php
    }
    ?>
                        </tbody>
                    </table>
            

                <br>
                <?php
                if(!empty($scoretab[12])){
                ?>
                
                    <table>
                        <h3>Demi Finale</h3>
                        <thead>
                            <tr>
                                <th>Demin-Finale</th>
                                <th>Affiche</th>
                                <th>Score</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>                
                                <td>13eme Match</td>
                                <td><?= $teamC[1]->getNom() ?> VS <?= $teamC[2]->getNom() ?></td>
                                <td><input type="number" disabled="" value="<?= empty($scoretab[13]) ? null : $scoretab[13]->getTeam1() ?>" name="match13"> - 
                                    <input type="number" placeholder="saisir score" disabled="" value="<?= empty($scoretab[13]) ? null : $scoretab[13]->getTeam2() ?>" name="match13-13"></td>
                            </tr>
                            <tr>
                                <td>14eme Match</td>
                                <td><?= $teamC[3]->getNom() ?> VS <?= $teamC[4]->getNom() ?></td>
                                <td><input type="number" disabled="" value="<?= empty($scoretab[14]) ? null : $scoretab[14]->getTeam1() ?>" name="match14"> - 
                                    <input type="number" disabled="" value="<?= empty($scoretab[14]) ? null : $scoretab[14]->getTeam2() ?>" name="match14-14"></td>
                            </tr>                    
                        </tbody>            
                    </table>
                <br>
    <?php
                }
    if (!empty($scoretab[13]) && !empty($scoretab[14])) {
        $teamD[1] = team::demiFinal($teamC, $scoretab, 1, 2, 13);
        $teamD[2] = team::demiFinal($teamC, $scoretab, 3, 4, 14);
        ?>   
                
                    <table>
                        <h3>Finale</h3>
                            <thead>
                                <tr>
                                    <th>Finale</th>
                                    <th>Affiche</th>
                                    <th>Score</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>                
                                    <td>15eme Match</td>
                                    <td><?= $teamD[1]->getNom() ?> VS <?= $teamD[2]->getNom() ?></td>
                                    <td><input type="number" disabled="" value="<?= empty($scoretab[15]) ? null : $scoretab[15]->getTeam1() ?>" name="match15"> - 

                                        <input type="number" disabled="" value="<?= empty($scoretab[15]) ? null : $scoretab[15]->getTeam2() ?>" name="match15-15"></td>
                                </tr>                    
                            </tbody>            
                        </table>  
        <?php
    }
    if (!empty($scoretab[15])) {
        $teamChampion = team::demiFinal($teamD, $scoretab, 1, 2, 15);
        ?>

                               <h1 class="text-align-center"> <?= $teamChampion->getNom() ?> Sacre Champion!!!!!!!!!!!!!!!!!!</h1>
                    
                    <?php
                }
            }
            ?>

</div>
</div>
</div>
</div>
</div>
















                   </div>
        </form>

    </body>
</html>
