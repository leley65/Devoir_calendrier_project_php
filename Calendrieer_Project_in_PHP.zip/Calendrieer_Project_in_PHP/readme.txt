Membre du groupe :
Eddyson Stephen Joseph (31857)
Jeff Deisma (30974)
Peterson Sylne (30898)
Wenley Jean Pierre (30817)