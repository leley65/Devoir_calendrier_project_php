<?php
include 'methods.php';

$submit = $_POST['submit'];

$match = $_POST;


switch ($submit) {
    case 'Tirage':
        tirage($Teamtable);
        unset($_SESSION['scoretab']);
        break;
    
    case 'Simulation':
        $_SESSION['scoretab'] = simulationauto();
        break;

    case 'Reinitialiser':
        session_destroy();
        break;
    
    default:
        break;
}

header("location:/Calendrieer_Project_in_PHP/index.php");
exit();

?>