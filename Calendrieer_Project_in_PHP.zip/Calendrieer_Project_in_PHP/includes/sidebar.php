<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link rel="stylesheet" type="text/css" href="includes\css\sidebar.css">

	<script type="text/javascript" src="custom\all.js"></script>
	<script type="text/javascript" src="includes\js\sidebar.js"></script>
</head>
<body>
	 <div class="sidebar">
            <div class="logo_content">
                <div class="logo">
                    <span class="icon"><i class="fas fa-truck-monster"></i></span>
                    <div class="logo_name">Auto Parts</div>
                </div>
                <div class="toggle" onclick="toggleMenu();">
                <span class="icon"><i class="fas fa-bars" id="btn"></i></span>
                </div>
            </div>
            <ul class="nav_list">
                <li>
                    <a href="#">
                    <span class="icon"><i class="fas fa-futbol"></i></span>
                        <span class="links_name"><input type='submit' value="Tirage" name="submit"></span>
                    </a>
                     <span class="tooltip">Tirage</span> 
                </li>
                <li>
                    <a href="#">
                        <span class="icon"><i class="fas fa-cogs"></i></span>
                        <span class="links_name"><input type='submit' value="Simulation" name="submit"></span>
                    </a>
                     <span class="tooltip">Simulation</span>
                </li>
                <li>
                    <a href="#">
                        <span class="icon"><i class="fas fa-dollar-sign"></i></span>
                        <span class="links_name"><input type='submit' value="Save" name="submit"></span>
                    </a>
                    <span class="tooltip">Vente</span> 
                </li>
                <li>
                    <a href="#">
                        <span class="icon"><i class="fas fa-sign-out-alt"></i></span>
                        <span class="links_name"><input type='submit' value="Reintialiser" name="submit"></span>
                    </a>
                     <span class="tooltip">Reintialiser</span> 
                </li>
            </ul>
        </div>
</body>
</html>