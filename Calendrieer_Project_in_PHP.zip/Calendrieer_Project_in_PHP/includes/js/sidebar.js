            function toggleMenu() {
    let toggle = document.querySelector('.toggle');
    let sidebar = document.querySelector('.sidebar');

    toggle.classList.toggle('active');
    sidebar.classList.toggle('active');
}

