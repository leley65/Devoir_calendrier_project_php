
<?php
session_start();
include 'team.class.php';
include 'score.class.php';

$team1 = new team('Brésil', 1);
$team2 = new team('Argentine', 1);
$team3 = new team('France', 2);
$team4 = new team('Italie', 2);
$team5 = new team('Espagne', 3);
$team6 = new team('Allemagne', 3);
$team7 = new team('Portugual', 4);
$team8 = new team('Haiti', 4);

$Teamtable = array($team1, $team2, $team3, $team4, $team5, $team6, $team7, $team8);

function tirage($table){
    $ta = array();
    $tb = array();
       
       foreach ($table as $value) {
           
       $num = array_rand($table, 1);
       if(!checkLot($ta, $table[$num])){
           $ta[$table[$num]->getLot()] = $table[$num];
       }else{
           $tb[$table[$num]->getLot()] = $table[$num];
       }
       unset($table[$num]);
   } 
   
   $_SESSION['first'] = $ta;
   $_SESSION['second'] = $tb;
   
}

function checkLot($a, $team) {
    $check = false;
    foreach ($a as $key) {
        if ($key->getLot() == $team->getLot()) {
            $check = true;
            break;
        }
    }
    return $check;
}

function simulationAuto(){
    for($i=1; $i <=15; $i++){
        $scoretable[$i] = new score(rand(0, 5),  rand(0, 5));
    }    
    return $scoretable;
}

function setScore($table){
    for ($i = 1; $i <=15; $i++){
        if($table["match".$i]!=null && $table["match".$i."-".$i]!=null){
            $scoretab[$i] = new score($table["match".$i], $table["match".$i."-".$i]);
        }  else {
            $scoretab[$i] = null;
        }
    }
    return $scoretab;
}

